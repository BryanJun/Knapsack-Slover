#!/usr/bin/env python
# coding: utf-8

# In[4]:


import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
'''
Below are Knapsack Functions
'''

##unbounded knapsack
def knapSack_cannot_repeat(capacity, weights, benifits):
    length = len(benifits)
    P = [[0 for x in range(capacity + 1)] for x in range(length + 1)]
    
    # algorithm for knapsack with item cannot repeat

    for i in range(length + 1):
        for j in range(capacity + 1):
            if i == 0 or j == 0:
                P[i][j] = 0
    
            elif weights[i - 1] <= j:
                P[i][j] = max(benifits[i - 1] + P[i - 1][j - weights[i - 1]], P[i - 1][j])
                
            else:
                P[i][j] = P[i - 1][j]
    output = 'the optimal solution is :' + '\n'+str(P[length][capacity])
    messagebox.showinfo("showinfo", output)
    print(P[length][capacity])


#0/1 knapsack
def Knapsack_repeat(capacity, benifits, weights):
    # capacity value ---> i
    # snap[i] ---> store maximum value
    length = len(benifits)
    snap = [0 for i in range(capacity + 1)]
    count = 0

    # algorithm for knapsack with item can be repeat
    for i in range(capacity + 1):
        for j in range(length):
            if (weights[j] <= i):
                snap[i] = max(snap[i], snap[i - weights[j]] + benifits[j])
    output = 'the optimal solution is :' + '\n'+str(snap[capacity])
    messagebox.showinfo("showinfo", output)
    print(snap[capacity])


###############################################################################
# Creating tkinter window

win = tk.Tk()
win.geometry("600x400")
win.minsize(width=700,height=600)
win.config(bg='skyblue')
win.title('Group 3: Knapsack Slover')
'''
Entry Cell
'''

#weights
ttk.Label(win, text = "Please Enter weights (Ex: 1,2,3):", 
        font = ("Times New Roman", 13)).grid(column = 0, 
        row = 15, padx = 10, pady = 15)
weights=tk.Entry()
weights.grid(column = 1, row = 15)

#benifits
ttk.Label(win, text = "Please Enter benifits (Ex: 11,22,31):", 
        font = ("Times New Roman", 13)).grid(column = 0, 
        row = 20, padx = 10, pady = 25)
benifits=tk.Entry()
benifits.grid(column = 1, row = 20)

#capacity
ttk.Label(win, text = "Please Enter capacity (Ex: 10):", 
        font = ("Times New Roman", 13)).grid(column = 0, 
        row = 25, padx = 10, pady = 15)
capacitys=tk.Entry()
capacitys.grid(column = 1, row = 25)

'''
Below are the codes for choosing knapsack and debug
'''
def command():
    weight = weights.get().split(",")
    try:
        weight = list(map(int, weight))
    except ValueError:
        messagebox.showerror("showerror", "weight must in INTEGER form")    
    benifit = benifits.get().split(",")
    try:
        benifit = list(map(int, benifit))
    except ValueError:
        messagebox.showerror("showerror", "benifit must in INTEGER form")    
    try:
        capacity = int(capacitys.get())
    except ValueError:
        messagebox.showerror("showerror", "capacity must in INTEGER form and UNIQUE") 
    if capacity >=10000000:
        messagebox.showerror("showerror", "capacity must cannot exceed 10,000,000")
    else:
        if len(benifit)==len(weight):
            button_un = tk.Button(win, text="Unbounded Knapsack Problem",
                                  command=lambda:Knapsack_repeat(capacity, benifit,weight))
            button_01 = tk.Button(win, text="0/1 Knapsack Problem",
                                  command=lambda:knapSack_cannot_repeat(capacity, weight, benifit))
            button_un.grid(column = 0, row = 40)
            button_01.grid(column = 2, row = 40)

        else:      
            messagebox.showerror("showerror", "The total item in weights and benifits are different!!")    

# calculate button
ttk.Label(win, text = "***Please click 'Calculate' after change value***", 
        font = ("Times New Roman", 15)).grid(column = 1, 
        row = 30, padx = 0, pady = 25)
button = tk.Button(win, text="Calcuate", command=command)
button.grid(column = 1, row = 35)
#2nd method for choosing knapsack
'''
# Label
ttk.Label(win, text = "Select the Type of Snapsack :", 
        font = ("Times New Roman", 13)).grid(column = 0, 
        row = 30, padx = 10, pady = 15)
n = tk.StringVar()
ty = ttk.Combobox(win, width = 27, textvariable = n)
  
# Adding combobox drop down list
ty['values'] = ('Please Choose One:',
                'Unbounded Knapsack Problem',
                '0-1 Knapsack Problem')
  
ty.grid(column = 1, row = 30)

ty.bind("<<Unbounded Knapsack Problem>>", Knapsack_repeat(capacity, benifit, weight) )
# Shows february as a default value
ty.current(0) 
'''

win.mainloop()


# In[2]:





# In[ ]:




